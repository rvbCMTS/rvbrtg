import dataclasses
import logging
import os
from datetime import datetime
from itertools import compress
from typing import Any, Optional

import pandas as pd
import requests

from .constants import (
    FILTER_PATIENT_AGE_TAG,
    FILTER_PATIENT_SIZE_TAG,
    FILTER_PATIENT_WEIGHT_TAG,
    FILTER_STUDY_TIME_INTERVAL_TAG,
)
from .rembox_analysis import REMboxFilter, SeriesColumn, StudyColumn

logger = logging.getLogger("rembox_integration_tools")


class REMboxDataQuery:
    """
    A class used to do queries against the REMbox analysis data API.

    I utilize a client ID and secret set in the environment variables for authenticating against the API

    Attributes:
        api_uri (str): The URI to the REMbox API

        access_token (str): The access token that the API returns at authentication

        origin_uri (str): The URI to specify as origin in the queries towards REMbox's API

        token_type (str): The type of the access token

        verify_ssl_cert (bool): Whether the SSL certificate should be verified or not. Defaults to `True`

        filter_options (str): Filter options that are applied when

    """

    def __init__(
        self,
        client_id_environment_variable: str,
        client_secret_environment_variable: str,
        api_uri: Optional[str] = None,
        origin_uri: Optional[str] = None,
        verify_ssl_cert: bool = True,
        token_uri: Optional[str] = None,
    ):
        """
        Args:
            client_id_environment_variable: The environment variable name containing the client id for authentication
            client_secret_environment_variable: The environment variable name containing the client secret for
                authentication
            api_uri: The URI to the REMbox API
            origin_uri: The URI to specify as origin for the API request
            verify_ssl_cert: Whether the SSL certificate should be verified or not. Defaults to `True`
            token_uri: The URI to the token endpoint
        """
        if api_uri is None:
            api_uri = os.getenv("REMBOX_API_URL")

        if origin_uri is None:
            origin_uri = os.getenv("REMBOX_INTEGRATION_ORIGIN_URI")

        self.api_uri = api_uri.removesuffix("/")
        self.origin_uri = origin_uri
        self.verify_ssl_cert = verify_ssl_cert
        self.token_uri = token_uri if token_uri is not None else self._set_default_token_uri()
        self.token_type, self.access_token = self._get_access_token(
            client_id_environment_variable=client_id_environment_variable,
            client_secret_environment_variable=client_secret_environment_variable,
        )
        self.filter_options = self._get_default_filter_options()
        self.columns = []

        self._study_columns: list[str] = [field.default for field in dataclasses.fields(StudyColumn)]
        self._series_columns: list[str] = [field.default for field in dataclasses.fields(SeriesColumn)]

    def _set_default_token_uri(self):
        self.token_uri = self.api_uri.removesuffix("api") + "/dpqaauth/connect/token"

    def _get_access_token(
        self, client_id_environment_variable: str, client_secret_environment_variable: str
    ) -> tuple[str, str]:
        headers = {"Origin": self.origin_uri} if self.origin_uri is not None else None

        res = requests.post(
            self.token_uri,
            data={
                "grant_type": "client_credentials",
                "client_id": os.getenv(client_id_environment_variable),
                "client_secret": os.getenv(client_secret_environment_variable),
            },
            verify=self.verify_ssl_cert,
            headers=headers,
        )

        if res.status_code != 200:
            logger.error(f"Failed to get access token. HTTP{res.status_code}: {res.text}")
            raise ValueError(f"Failed to get access token\t{res.text}")

        res_val = res.json()

        return res_val.get("token_type"), res_val.get("access_token")

    def _get_default_filter_options(self):
        headers = {} if self.origin_uri is None else {"Origin": self.origin_uri}
        headers["Authorization"] = f"{self.token_type} {self.access_token}"

        res = requests.get(f"{self.api_uri}/analysis/filteroptions", headers=headers)

        if res.status_code != 200:
            raise ValueError(
                f"Failed to get filter options from API endpoint. Status code: HTTP{res.status_code}, Response: {res.text}"
            )

        res = res.json()

        return REMboxFilter(
            study_time_interval_start_date=datetime.strptime(
                res[FILTER_STUDY_TIME_INTERVAL_TAG]["startDate"], "%Y-%m-%dT%H:%M:%SZ"
            ),
            study_time_interval_end_date=datetime.strptime(
                res[FILTER_STUDY_TIME_INTERVAL_TAG]["endDate"], "%Y-%m-%dT%H:%M:%SZ"
            ),
            study_time_interval_min_date=datetime.strptime(
                res[FILTER_STUDY_TIME_INTERVAL_TAG]["minDate"], "%Y-%m-%dT%H:%M:%SZ"
            ),
            study_time_interval_selected_quick_option=res[FILTER_STUDY_TIME_INTERVAL_TAG]["selectedQuickOption"],
            patient_age_interval_start_value=res[FILTER_PATIENT_AGE_TAG]["start"]["value"],
            patient_age_interval_start_unit=res[FILTER_PATIENT_AGE_TAG]["start"]["unit"],
            patient_age_interval_end_value=res[FILTER_PATIENT_AGE_TAG]["end"]["value"],
            patient_age_interval_end_unit=res[FILTER_PATIENT_AGE_TAG]["end"]["unit"],
            patient_age_interval_include_nulls=res[FILTER_PATIENT_AGE_TAG]["includeNulls"],
            patient_size_in_centimeters_start=res[FILTER_PATIENT_SIZE_TAG]["start"],
            patient_size_in_centimeters_end=res[FILTER_PATIENT_SIZE_TAG]["end"],
            patient_size_in_centimeters_include_nulls=res[FILTER_PATIENT_SIZE_TAG]["includeNulls"],
            patient_weight_in_kilograms_start=res[FILTER_PATIENT_WEIGHT_TAG]["start"],
            patient_weight_in_kilograms_end=res[FILTER_PATIENT_WEIGHT_TAG]["end"],
            patient_weight_in_kilograms_include_nulls=res[FILTER_PATIENT_WEIGHT_TAG]["includeNulls"],
            hospitals=[obj["name"] for obj in res["hospitals"]],
            machine_types=[obj["name"] for obj in res["machineTypes"]],
            study_types=[obj["name"] for obj in res["studyTypes"]],
            machines=[obj["name"] for obj in res["machines"]],
            study_descriptions=[obj["name"] for obj in res["studyDescriptions"]["tags"]],
            study_descriptions_include_nulls=res["studyDescriptions"]["includeNulls"],
            procedures=[obj["name"] for obj in res["procedures"]["tags"]],
            procedures_include_nulls=res["procedures"]["includeNulls"],
            protocols=[obj["name"] for obj in res["protocols"]["tags"]],
            protocols_include_nulls=res["protocols"]["includeNulls"],
            acquisition_protocols=[obj["name"] for obj in res["acquisitionProtocols"]["tags"]],
            acquisition_protocols_include_nulls=res["acquisitionProtocols"]["includeNulls"],
        )

    def _get_data_request_headers(self) -> dict[str, Any]:
        headers = {} if self.origin_uri is None else {"Origin": self.origin_uri}
        headers["Authorization"] = f"{self.token_type} {self.access_token}"

        return headers

    def reset_filter_options(self):
        """Rests the filter options to the defaults fetched from the API"""
        self.filter_options = self._get_default_filter_options()

    def add_columns(self, columns: list[str]):
        """
        Adds the list of column names to the column set to be fetched from the API

        Args:
            columns: A list of column names to add to the list
        """
        if not isinstance(columns, list) or any([not isinstance(column, str) for column in columns]):
            raise TypeError("The columns must be given as a list of strings")

        valid_columns = self._study_columns + self._series_columns
        invalid_columns = [column not in valid_columns for column in columns]

        if any(invalid_columns):
            invalid_column_string = ", ".join(list(compress(valid_columns, invalid_columns)))
            raise ValueError(
                f"Invalid column names found in supplied list. Invalid column names: {invalid_column_string}"
            )

        self.columns = self.columns + [col for col in columns if col not in self.columns]

    def remove_column(self, column: str):
        """
        Removes the column name from the column set to be fetched from the API

        Args:
            column: A column name to remove from the list
        """
        try:
            self.columns.remove(column)
        except ValueError:
            logger.error(f"The column '{column}' was not found in the list of column ")

    def clear_column_choice(self):
        """Clears the column choices"""
        self.columns = []

    def get_request_body(self) -> dict[str, Any]:
        """
        Composes the analysis data request body into a dict
        """
        return self.filter_options.to_request_dict(columns=self.columns)

    def run_query(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Fetches data from the API using the set filter options and columns

        Returns:
                A tuple of two Pandas DataFrames containing the study and series level data, respectively
        """
        if not self.columns:
            raise ValueError("No columns are specified")
        logger.info("Fetching study data from REMbox API")
        table_data_uri = f"{self.api_uri}/analysis/table"

        headers = self._get_data_request_headers()

        res = requests.post(table_data_uri, headers=headers, json=self.get_request_body(), verify=self.verify_ssl_cert)

        if res.status_code != 200:
            logger.error(f"Fetching study data failed. Status code: HTTP{res.status_code}, Response: {res.text}")
            raise ValueError(
                f"Failed to get table data from API endpoint. Status code: HTTP{res.status_code}, Response: {res.text}"
            )

        res = res.json()

        valid_study_columns = StudyColumn()

        study_df = pd.DataFrame([row.get("study") for row in res])
        series_df = pd.DataFrame(
            [
                series
                | {
                    "studyId": row["study"].get(valid_study_columns.Id),
                    valid_study_columns.StudyInstanceUID: row["study"].get(valid_study_columns.StudyInstanceUID),
                    valid_study_columns.AccessionNumber: row["study"].get(valid_study_columns.AccessionNumber),
                }
                for row in res
                for series in row.get("seriesList")
            ]
        )

        if valid_study_columns.StudyInstanceUID not in study_df.columns:
            series_df.drop([valid_study_columns.StudyInstanceUID], axis=1)

        if valid_study_columns.AccessionNumber not in study_df.columns:
            series_df.drop([valid_study_columns.AccessionNumber], axis=1)

        logger.info(f"Received {len(study_df)} Study rows and {len(series_df)} Series rows")

        return study_df, series_df

    def get_data_for_pyskindose_analysis(
        self, study_id: Optional[int] = None, study_instance_uid: str = None, accession_number: Optional[str] = None
    ) -> tuple[pd.DataFrame, dict]:
        """
        Retrieves normalized PySkinDose data for the supplied study id or the combination of study instance UID and
        accession number

        Returns:
            A tuple of the exam data normalized for PySkinDose calculations and a dict containing the machine specific
            settings
        """
        if study_id is not None:
            if not isinstance(study_id, int):
                raise TypeError("The study id must be given as an integer")

            params = {"id": study_id}
            logger.info("Fetching PySkinDose normalized data for study based on id")
        else:
            if study_instance_uid is not None and not isinstance(study_instance_uid, str):
                raise TypeError("The study instance UID must be given as a string")
            if accession_number is not None and not isinstance(accession_number, str):
                raise TypeError("The study instance UID must be given as a string")

            params = {"studyInstanceUid": study_instance_uid, "accessionNumber": accession_number}
            logger.info("Fetching PySkinDose normalized data for study based on StudyInstanceUID and AccessionNumber")

        pyskindose_data_uri = f"{self.api_uri}/analysis/pyskindose"

        res = requests.get(pyskindose_data_uri, params=params, headers=self._get_data_request_headers())

        res = res.json()

        normalized_pyskindose_data = pd.DataFrame(res.get("StudyDataList"))
        logger.info(f"Found PySKinDose normalized data for {len(normalized_pyskindose_data)} exposures")

        return normalized_pyskindose_data, res.get("MachineSpecificSettings")
