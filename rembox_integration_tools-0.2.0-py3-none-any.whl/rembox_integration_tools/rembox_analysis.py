import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from rembox_integration_tools.constants import (
    FILTER_PATIENT_AGE_TAG,
    FILTER_PATIENT_SIZE_TAG,
    FILTER_PATIENT_WEIGHT_TAG,
    FILTER_STUDY_TIME_INTERVAL_TAG,
)


class REMboxFilter:
    def __init__(
        self,
        study_time_interval_start_date: datetime,
        study_time_interval_end_date: datetime,
        study_time_interval_min_date: datetime,
        study_time_interval_selected_quick_option: Optional[str] = "lastThreeMonths",
        patient_age_interval_start_value: Optional[int] = 0,
        patient_age_interval_start_unit: Optional[str] = "Y",
        patient_age_interval_end_value: Optional[int] = 110,
        patient_age_interval_end_unit: Optional[str] = "Y",
        patient_age_interval_include_nulls: Optional[bool] = False,
        patient_size_in_centimeters_start: Optional[int] = 0,
        patient_size_in_centimeters_end: Optional[int] = 240,
        patient_size_in_centimeters_include_nulls: Optional[bool] = True,
        patient_weight_in_kilograms_start: Optional[int] = 0,
        patient_weight_in_kilograms_end: Optional[int] = 240,
        patient_weight_in_kilograms_include_nulls: Optional[bool] = True,
        hospitals: Optional[list[str]] = None,
        machine_types: Optional[list[str]] = None,
        study_types: Optional[list[str]] = None,
        machines: Optional[list[str]] = None,
        study_descriptions: Optional[list[str]] = None,
        study_descriptions_include_nulls: Optional[bool] = True,
        procedures: Optional[list[str]] = None,
        procedures_include_nulls: Optional[bool] = True,
        protocols: Optional[list[str]] = None,
        protocols_include_nulls: Optional[bool] = True,
        acquisition_protocols: Optional[list[str]] = None,
        acquisition_protocols_include_nulls: Optional[bool] = True,
    ):
        self._study_time_interval_start_date = study_time_interval_start_date
        self._study_time_interval_end_date = study_time_interval_end_date
        self.study_time_interval_min_date = study_time_interval_min_date
        self._study_time_interval_selected_quick_option = study_time_interval_selected_quick_option
        self.patient_age_interval_start_value = patient_age_interval_start_value
        self.patient_age_interval_start_unit = patient_age_interval_start_unit
        self.patient_age_interval_end_value = patient_age_interval_end_value
        self.patient_age_interval_end_unit = patient_age_interval_end_unit
        self.patient_age_interval_include_nulls = patient_age_interval_include_nulls
        self.patient_size_in_centimeters_start = patient_size_in_centimeters_start
        self.patient_size_in_centimeters_end = patient_size_in_centimeters_end
        self.patient_size_in_centimeters_include_nulls = patient_size_in_centimeters_include_nulls
        self.patient_weight_in_kilograms_start = patient_weight_in_kilograms_start
        self.patient_weight_in_kilograms_end = patient_weight_in_kilograms_end
        self.patient_weight_in_kilograms_include_nulls = patient_weight_in_kilograms_include_nulls
        self.hospitals: list[dict[str, str]] = []
        self.machine_types: list[dict[str, str]] = []
        self.study_types: list[dict[str, str]] = []
        self.machines: list[dict[str, str]] = []
        self.study_descriptions: list[dict[str, str]] = []
        self.study_descriptions_include_nulls: bool = study_descriptions_include_nulls
        self.procedures: list[dict[str, str]] = []
        self.procedures_include_nulls: bool = procedures_include_nulls
        self.protocols: list[dict[str, str]] = []
        self.protocols_include_nulls: bool = protocols_include_nulls
        self.acquisition_protocols: list[dict[str, str]] = []
        self.acquisition_protocols_include_nulls: bool = acquisition_protocols_include_nulls

        self.set_neutral_tags(
            hospitals=hospitals,
            machine_types=machine_types,
            study_types=study_types,
            machines=machines,
            study_descriptions=study_descriptions,
            procedures=procedures,
            protocols=protocols,
            acquisition_protocols=acquisition_protocols,
        )

    @property
    def study_time_interval_start_date(self):
        return self._study_time_interval_start_date

    @property
    def study_time_interval_end_date(self):
        return self._study_time_interval_end_date

    @property
    def study_time_interval_selected_quick_option(self):
        return self._study_time_interval_selected_quick_option

    @study_time_interval_start_date.setter
    def study_time_interval_start_date(self, new_value: str):
        start_date = datetime.strptime(new_value, "%Y-%m-%dT%H:%M:%SZ")
        self._study_time_interval_start_date = start_date
        self._study_time_interval_selected_quick_option = None

    @study_time_interval_end_date.setter
    def study_time_interval_end_date(self, new_value: str):
        end_date = datetime.strptime(new_value, "%Y-%m-%dT%H:%M:%SZ")
        self._study_time_interval_end_date = end_date
        self._study_time_interval_selected_quick_option = None

    @study_time_interval_selected_quick_option.setter
    def study_time_interval_selected_quick_option(self, new_value: str):
        valid_quick_options = ("lastOneMonth", "lastThreeMonths", "lastTwelveMonths", "thisYear", "lastYear")
        if new_value not in valid_quick_options:
            message = (
                f"New value not a valid time interval quick option. Valid options are {', '.join(valid_quick_options)}"
            )
            raise ValueError(message)

        current_datetime = datetime.utcnow()
        current_month = current_datetime.month
        self._study_time_interval_end_date = current_datetime.strftime("%Y-%m-%dT%H:%M:%ST")

        if new_value == valid_quick_options[0]:

            if current_month == 1:
                new_start_time = current_datetime.replace(year=current_datetime.year - 1, month=12)
            else:
                new_start_time = current_datetime.replace(month=current_month - 1)

            new_start_time.replace(hour=0, minute=0, second=0, microsecond=0)

        if new_value.endswith("Months"):
            self._study_time_interval_end_date = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%ST")
            month_interval = new_value.lstrip("last").rstrip("Months")
            if month_interval == "Twelve":
                new_start_time = current_datetime.replace(
                    year=current_datetime.year - 1, hour=0, minute=0, second=0, microsecond=0
                )
            elif month_interval == "Three":
                if current_month <= 3:
                    new_start_time = current_datetime.replace(
                        year=current_datetime.year - 1,
                        month=12 - (current_month - 3),
                        hour=0,
                        minute=0,
                        second=0,
                        microsecond=0,
                    )
                else:
                    new_start_time = current_datetime.replace(month=current_month - 3)
            else:
                raise ValueError("Invalid study time interval quick set value chosen")
        else:
            new_start_time = current_datetime.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
            if new_value.startswith("previous"):
                self._study_time_interval_end_date = new_start_time
                new_start_time = new_start_time.replace(year=new_start_time.year - 1)

        self._study_time_interval_start_date = new_start_time

        self._study_time_interval_selected_quick_option = new_value

    @staticmethod
    def _get_tag_list_inclusive(tag_list: list[str]) -> list[dict[str, str]]:
        return [{"name": tag, "filterMode": "inclusive"} for tag in tag_list]

    def set_inclusive_tags(
        self,
        hospitals: Optional[list[str]] = None,
        machine_types: Optional[list[str]] = None,
        study_types: Optional[list[str]] = None,
        machines: Optional[list[str]] = None,
        study_descriptions: Optional[list[str]] = None,
        procedures: Optional[list[str]] = None,
        protocols: Optional[list[str]] = None,
        acquisition_protocols: Optional[list[str]] = None,
    ):
        self.hospitals = self._set_inclusive_tags(current_tags=self.hospitals, inclusive_tags=hospitals)
        self.machine_types = self._set_inclusive_tags(current_tags=self.machine_types, inclusive_tags=machine_types)
        self.study_types = self._set_inclusive_tags(current_tags=self.study_types, inclusive_tags=study_types)
        self.machines = self._set_inclusive_tags(current_tags=self.machines, inclusive_tags=machines)
        self.study_descriptions = self._set_inclusive_tags(
            current_tags=self.study_descriptions, inclusive_tags=study_descriptions
        )
        self.procedures = self._set_inclusive_tags(current_tags=self.procedures, inclusive_tags=procedures)
        self.protocols = self._set_inclusive_tags(current_tags=self.protocols, inclusive_tags=protocols)
        self.acquisition_protocols = self._set_inclusive_tags(
            current_tags=self.acquisition_protocols, inclusive_tags=acquisition_protocols
        )

    def set_neutral_tags(
        self,
        hospitals: Optional[list[str]] = None,
        machine_types: Optional[list[str]] = None,
        study_types: Optional[list[str]] = None,
        machines: Optional[list[str]] = None,
        study_descriptions: Optional[list[str]] = None,
        procedures: Optional[list[str]] = None,
        protocols: Optional[list[str]] = None,
        acquisition_protocols: Optional[list[str]] = None,
    ):
        self.hospitals = self._set_neutral_tags(current_tags=self.hospitals, neutral_tags=hospitals)
        self.machine_types = self._set_neutral_tags(current_tags=self.machine_types, neutral_tags=machine_types)
        self.study_types = self._set_neutral_tags(current_tags=self.study_types, neutral_tags=study_types)
        self.machines = self._set_neutral_tags(current_tags=self.machines, neutral_tags=machines)
        self.study_descriptions = self._set_neutral_tags(
            current_tags=self.study_descriptions, neutral_tags=study_descriptions
        )
        self.procedures = self._set_neutral_tags(current_tags=self.procedures, neutral_tags=procedures)
        self.protocols = self._set_neutral_tags(current_tags=self.protocols, neutral_tags=protocols)
        self.acquisition_protocols = self._set_neutral_tags(
            current_tags=self.acquisition_protocols, neutral_tags=acquisition_protocols
        )

    def set_exclusive_tags(
        self,
        hospitals: Optional[list[str]] = None,
        machine_types: Optional[list[str]] = None,
        study_types: Optional[list[str]] = None,
        machines: Optional[list[str]] = None,
        study_descriptions: Optional[list[str]] = None,
        procedures: Optional[list[str]] = None,
        protocols: Optional[list[str]] = None,
        acquisition_protocols: Optional[list[str]] = None,
    ):
        self.hospitals = self._set_exclusive_tags(current_tags=self.hospitals, exclusive_tags=hospitals)
        self.machine_types = self._set_exclusive_tags(current_tags=self.machine_types, exclusive_tags=machine_types)
        self.study_types = self._set_exclusive_tags(current_tags=self.study_types, exclusive_tags=study_types)
        self.machines = self._set_exclusive_tags(current_tags=self.machines, exclusive_tags=machines)
        self.study_descriptions = self._set_exclusive_tags(
            current_tags=self.study_descriptions, exclusive_tags=study_descriptions
        )
        self.procedures = self._set_exclusive_tags(current_tags=self.procedures, exclusive_tags=procedures)
        self.protocols = self._set_exclusive_tags(current_tags=self.protocols, exclusive_tags=protocols)
        self.acquisition_protocols = self._set_exclusive_tags(
            current_tags=self.acquisition_protocols, exclusive_tags=acquisition_protocols
        )

    @staticmethod
    def _set_neutral_tags(current_tags: Optional[list[dict[str, str]]], neutral_tags: Optional[list[str]]):
        if current_tags is None:
            current_tags = []

        if neutral_tags is None:
            return current_tags

        current_tags = [tag for tag in current_tags if tag["name"] not in neutral_tags]

        return current_tags + [{"name": tag, "filterMode": "neutral"} for tag in neutral_tags]

    @staticmethod
    def _set_inclusive_tags(current_tags: Optional[list[dict[str, str]]], inclusive_tags: Optional[list[str]]):
        if current_tags is None:
            current_tags = []

        if inclusive_tags is None:
            return current_tags

        current_tags = [tag for tag in current_tags if tag["name"] not in inclusive_tags]

        return current_tags + [{"name": tag, "filterMode": "inclusive"} for tag in inclusive_tags]

    @staticmethod
    def _set_exclusive_tags(current_tags: Optional[list[dict[str, str]]], exclusive_tags: Optional[list[str]]):
        if current_tags is None:
            current_tags = []

        if exclusive_tags is None:
            return current_tags

        current_tags = [tag for tag in current_tags if tag["name"] not in exclusive_tags]

        return current_tags + [{"name": tag, "filterMode": "exclusive"} for tag in exclusive_tags]

    def to_request_dict(self, columns: list[str]):
        if not isinstance(columns, list) or len(columns) < 1:
            raise ValueError("Columns must be specified as a list of strings")

        if any([not isinstance(col, str) for col in columns]):
            raise ValueError("All columns")

        if "id" not in columns:
            columns.append("id")

        return {
            "filterOptions": {
                FILTER_STUDY_TIME_INTERVAL_TAG: {
                    "startDate": self.study_time_interval_start_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "endDate": self.study_time_interval_end_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "minDate": self.study_time_interval_min_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "selectedQuickOption": self.study_time_interval_selected_quick_option,
                },
                FILTER_PATIENT_AGE_TAG: {
                    "start": {
                        "unit": self.patient_age_interval_start_unit,
                        "value": self.patient_age_interval_start_value,
                    },
                    "end": {"unit": self.patient_age_interval_end_unit, "value": self.patient_age_interval_end_value},
                    "includeNulls": self.patient_age_interval_include_nulls,
                },
                FILTER_PATIENT_SIZE_TAG: {
                    "start": int(self.patient_size_in_centimeters_start),
                    "end": int(self.patient_size_in_centimeters_end),
                    "includeNulls": self.patient_size_in_centimeters_include_nulls,
                },
                FILTER_PATIENT_WEIGHT_TAG: {
                    "start": int(self.patient_weight_in_kilograms_start),
                    "end": int(self.patient_weight_in_kilograms_end),
                    "includeNulls": self.patient_weight_in_kilograms_include_nulls,
                },
                "hospitals": self.hospitals,
                "machineTypes": self.machine_types,
                "studyTypes": self.study_types,
                "machines": self.machines,
                "studyDescriptions": {
                    "tags": self.study_descriptions,
                    "includeNulls": self.study_descriptions_include_nulls,
                },
                "procedures": {"tags": self.procedures, "includeNulls": self.procedures_include_nulls},
                "protocols": {"tags": self.protocols, "includeNulls": self.protocols_include_nulls},
                "acquisitionProtocols": {
                    "tags": self.acquisition_protocols,
                    "includeNulls": self.acquisition_protocols_include_nulls,
                },
            },
            "columns": columns,
            "noStudyLimit": True,
        }


@dataclass
class StudyColumn:
    AccessionNumber: str = "accessionNumber"
    AccumulatedAverageGlandularDoseBothBreasts: str = "accumulatedAverageGlandularDoseBothBreasts"
    AccumulatedAverageGlandularDoseLeftBreast: str = "accumulatedAverageGlandularDoseLeftBreast"
    AccumulatedAverageGlandularDoseRightBreast: str = "accumulatedAverageGlandularDoseRightBreast"
    AccumulatedDose: str = "accumulatedDose"
    AcquisitionDeviceType: str = "acquisitionDeviceType"
    AcquisitionDoseAreaProductTotal: str = "acquisitionDoseAreaProductTotal"
    AcquisitionDoseRPTotal: str = "acquisitionDoseRPTotal"
    AcquisitionPlane: str = "acquisitionPlane"
    AdmittingDiagnosisCodeSequence: str = "admittingDiagnosisCodeSequence"
    AdmittingDiagnosisDescription: str = "admittingDiagnosisDescription"
    Allergies: str = "allergies"
    CalibrationDate: str = "calibrationDate"
    CalibrationFactor: str = "calibrationFactor"
    CalibrationProtocol: str = "calibrationProtocol"
    CalibrationResponsibleParty: str = "calibrationResponsibleParty"
    CalibrationUncertainty: str = "calibrationUncertainty"
    City: str = "city"
    ConsultingPhysicianIdentificationSequence: str = "consultingPhysicianIdentificationSequence"
    ConsultingPhysiciansName: str = "consultingPhysiciansName"
    ConvFluoroClassifier: str = "convFluoroClassifier"
    DetectorType: str = "detectorType"
    DlpTotal: str = "dlpTotal"
    DoseAreaProductTotal: str = "doseAreaProductTotal"
    DoseMeasurementDevice: str = "doseMeasurementDevice"
    DoseRPTotal: str = "doseRPTotal"
    DosimeterType: str = "dosimeterType"
    EffectiveDosePhantomType: str = "effectiveDosePhantomType"
    EffectiveDoseTotal: str = "effectiveDoseTotal"
    EndOfXrayIrradiation: str = "endOfXrayIrradiation"
    EquipmentModality: str = "equipmentModality"
    FluoroDoseAreaProductTotal: str = "fluoroDoseAreaProductTotal"
    FluoroDoseRPTotal: str = "fluoroDoseRPTotal"
    HalfValueLayer: str = "halfValueLayer"
    HasIntent: str = "hasIntent"
    Hospital: str = "hospital"
    Id: str = "id"
    IssuerOfAccessionNumber: str = "issuerOfAccessionNumber"
    LastMenstrualDate: str = "lastMenstrualDate"
    Machine: str = "machine"
    MaximumBodyThickness: str = "maximumBodyThickness"
    MeanBodyThickness: str = "meanBodyThickness"
    MeasuredAPDimension: str = "measuredAPDimension"
    MeasuredLateralDimension: str = "measuredLateralDimension"
    MeasurementMethod: str = "measurementMethod"
    MedicalAlerts: str = "medicalAlerts"
    MinimumBodyThickness: str = "minimumBodyThickness"
    NameOfPhysicianReadingStudy: str = "nameOfPhysicianReadingStudy"
    PatientAge: str = "patientAge"
    PatientAgeUnit: str = "patientAgeUnit"
    PatientId: str = "patientId"
    PatientDbId: str = "patientDbId"
    PatientModel: str = "patientModel"
    PatientsBodyMassIndex: str = "patientsBodyMassIndex"
    PatientsName: str = "patientsName"
    PatientsSex: str = "patientsSex"
    PatientsSize: str = "patientsSize"
    PatientsSizeDate: str = "patientsSizeDate"
    PatientsSizeSource: str = "patientsSizeSource"
    PatientsWeight: str = "patientsWeight"
    PatientsWeightDate: str = "patientsWeightDate"
    PatientsWeightSource: str = "patientsWeightSource"
    PerformingPhysicianIdentificationSequence: str = "performingPhysicianIdentificationSequence"
    PerformingPhysicianName: str = "performingPhysicianName"
    PhysiciansOfRecord: str = "physiciansOfRecord"
    PhysiciansOfRecordIdentificationSequence: str = "physiciansOfRecordIdentificationSequence"
    PhysiciansReadingStudyIdentificationSequence: str = "physiciansReadingStudyIdentificationSequence"
    PregnancyStatus: str = "pregnancyStatus"
    ProcedureCode: str = "procedureCode"
    ProcedureCodeMeaning: str = "procedureCodeMeaning"
    ProcedureReported: str = "procedureReported"
    ProtocolCode: str = "protocolCode"
    ProtocolCodeMeaning: str = "protocolCodeMeaning"
    QualityControlSubject: str = "qualityControlSubject"
    ReferenceAuthority: str = "referenceAuthority"
    ReferencedSopInstanceUid: str = "referencedSopInstanceUid"
    ReferencePointDefinition: str = "referencePointDefinition"
    ReferencePointDefinitionCode: str = "referencePointDefinitionCode"
    ReferringPhysicianIdentificationSequence: str = "referringPhysicianIdentificationSequence"
    ReferringPhysiciansName: str = "referringPhysiciansName"
    RequestedProcedureCode: str = "requestedProcedureCode"
    RequestedProcedureCodeMeaning: str = "requestedProcedureCodeMeaning"
    ScopeOfAccumulation: str = "scopeOfAccumulation"
    SmokingStatus: str = "smokingStatus"
    SoftwareVersions: str = "softwareVersions"
    StartOfXrayIrradiation: str = "startOfXrayIrradiation"
    StudyDateTime: str = "studyDateTime"
    StudyDescription: str = "studyDescription"
    StudyId: str = "studyId"
    StudyInstanceUID: str = "studyInstanceUID"
    TotalAcquisitionTime: str = "totalAcquisitionTime"
    TotalFluoroTime: str = "totalFluoroTime"
    TotalNumberOfIrradiationEvents: str = "totalNumberOfIrradiationEvents"
    TotalNumberOfRadiographicFrames: str = "totalNumberOfRadiographicFrames"


@dataclass
class SeriesColumn:
    AcquisitionPlaneSeries: str = "acquisitionPlaneSeries"
    AcquisitionProtocol: str = "acquisitionProtocol"
    AcquisitionType: str = "acquisitionType"
    AnatomicalStructure: str = "anatomicalStructure"
    AnodeTargetMaterial: str = "anodeTargetMaterial"
    AverageGlandularDose: str = "averageGlandularDose"
    AverageXrayTubeCurrent: str = "averageXrayTubeCurrent"
    BottomZLocationOfReconstructableVolume: str = "bottomZLocationOfReconstructableVolume"
    BottomZLocationOfScanningLength: str = "bottomZLocationOfScanningLength"
    BreastComposition: str = "breastComposition"
    CollimatedFieldArea: str = "collimatedFieldArea"
    CollimatedFieldHeight: str = "collimatedFieldHeight"
    CollimatedFieldWidth: str = "collimatedFieldWidth"
    ColumnAngulation: str = "columnAngulation"
    CompressionForce: str = "compressionForce"
    CompressionThickness: str = "compressionThickness"
    CrdrMechanicalConfiguration: str = "crdrMechanicalConfiguration"
    CtdiFreeAirCalculationFactor: str = "ctdiFreeAirCalculationFactor"
    CtdIwPhantomType: str = "ctdIwPhantomType"
    DateTimeStarted: str = "dateTimeStarted"
    DerivedEffectiveDiameter: str = "derivedEffectiveDiameter"
    DeviationIndex: str = "deviationIndex"
    DistanceSourceToDetector: str = "distanceSourceToDetector"
    DistanceSourceToIsocenter: str = "distanceSourceToIsocenter"
    DistanceSourceToReferencePoint: str = "distanceSourceToReferencePoint"
    DistanceSourceToTablePlane: str = "distanceSourceToTablePlane"
    DlPv: str = "dlPv"
    DoseAreaProduct: str = "doseAreaProduct"
    DoseRP: str = "doseRP"
    EffectiveDose: str = "effectiveDose"
    EffectiveDoseConversionFactor: str = "effectiveDoseConversionFactor"
    EntranceExposureAtRP: str = "entranceExposureAtRP"
    ExposedRange: str = "exposedRange"
    Exposure: str = "exposure"
    ExposureIndex: str = "exposureIndex"
    ExposureTime: str = "exposureTime"
    ExposureTimePerRotation: str = "exposureTimePerRotation"
    FluoroMode: str = "fluoroMode"
    FrameOfReferenceUID: str = "frameOfReferenceUID"
    IdentificationOfTheXraySource: str = "identificationOfTheXraySource"
    ImageView: str = "imageView"
    ImageViewModifier: str = "imageViewModifier"
    IrradiationDuration: str = "irradiationDuration"
    IrradiationEventLabel: str = "irradiationEventLabel"
    IrradiationEventType: str = "irradiationEventType"
    IrradiationEventUID: str = "irradiationEventUID"
    kVp: str = "kVp"
    LabelType: str = "labelType"
    Laterality: str = "laterality"
    MaximumXrayTubeCurrent: str = "maximumXrayTubeCurrent"
    MeanCTDIFreeAir: str = "meanCTDIFreeAir"
    MeanCTDIvol: str = "meanCTDIvol"
    MeasurementMethodDose: str = "measurementMethodDose"
    MeasurementMethodSSDE: str = "measurementMethodSSDE"
    NominalCollimationWidth: str = "nominalCollimationWidth"
    NominalTotalCollimationWidth: str = "nominalTotalCollimationWidth"
    NumberOfPulses: str = "numberOfPulses"
    NumberOfXraySources: str = "numberOfXraySources"
    PatientEquivalentThickness: str = "patientEquivalentThickness"
    PatientOrientation: str = "patientOrientation"
    PatientOrientationModifier: str = "patientOrientationModifier"
    PatientTableRelationship: str = "patientTableRelationship"
    PercentFibroglandularTissue: str = "percentFibroglandularTissue"
    PitchFactor: str = "pitchFactor"
    PositionerPrimaryAngle: str = "positionerPrimaryAngle"
    PositionerPrimaryEndAngle: str = "positionerPrimaryEndAngle"
    PositionerSecondaryAngle: str = "positionerSecondaryAngle"
    PositionerSecondaryEndAngle: str = "positionerSecondaryEndAngle"
    ProcedureContext: str = "procedureContext"
    ProjectionEponymousName: str = "projectionEponymousName"
    PulseRate: str = "pulseRate"
    PulseWidth: str = "pulseWidth"
    ReconstructableVolumeLength: str = "reconstructableVolumeLength"
    ReconstructionAlgortihm: str = "reconstructionAlgortihm"
    ReferencePointDefinitionText: str = "referencePointDefinitionText"
    ScanningLength: str = "scanningLength"
    SeriesOrInstanceUsedForWEDEstimation: str = "seriesOrInstanceUsedForWEDEstimation"
    SizeSpecificDoseEstimation: str = "sizeSpecificDoseEstimation"
    SpotSize: str = "spotSize"
    TableCradleTiltAngle: str = "tableCradleTiltAngle"
    TableHeadTiltAngle: str = "tableHeadTiltAngle"
    TableHeightEndPosition: str = "tableHeightEndPosition"
    TableHeightPosition: str = "tableHeightPosition"
    TableHorizontalRotationAngle: str = "tableHorizontalRotationAngle"
    TableLateralEndPosition: str = "tableLateralEndPosition"
    TableLateralPosition: str = "tableLateralPosition"
    TableLongitudinalEndPosition: str = "tableLongitudinalEndPosition"
    TableLongitudinalPosition: str = "tableLongitudinalPosition"
    TargetExposureIndex: str = "targetExposureIndex"
    TargetRegion: str = "targetRegion"
    TopZLocationOfReconstructableVolume: str = "topZLocationOfReconstructableVolume"
    TopZLocationOfScanningLength: str = "topZLocationOfScanningLength"
    WaterEquivalentDiameter: str = "waterEquivalentDiameter"
    WedMeasurementMethod: str = "wedMeasurementMethod"
    XrayFilterAluminumEquivalent: str = "xrayFilterAluminumEquivalent"
    XrayFilterMaterial: str = "xrayFilterMaterial"
    XrayFilterThicknessMaximum: str = "xrayFilterThicknessMaximum"
    XrayFilterThicknessMinimum: str = "xrayFilterThicknessMinimum"
    XrayFilterType: str = "xrayFilterType"
    XrayGrid: str = "xrayGrid"
    XrayGridAspectRatio: str = "xrayGridAspectRatio"
    XrayGridFocalDistance: str = "xrayGridFocalDistance"
    XrayGridPitch: str = "xrayGridPitch"
    XrayModulationType: str = "xrayModulationType"
    XrayTubeCurrent: str = "xrayTubeCurrent"
    ZValueOfLocationOfWEDEstimation: str = "zValueOfLocationOfWEDEstimation"
