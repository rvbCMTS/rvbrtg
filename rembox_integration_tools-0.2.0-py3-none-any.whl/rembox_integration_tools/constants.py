FILTER_PATIENT_AGE_TAG = "patientAgeInterval"
FILTER_PATIENT_SIZE_TAG = "patientSizeInCentimetersInterval"
FILTER_PATIENT_WEIGHT_TAG = "patientWeightInKilogramsInterval"
FILTER_STUDY_TIME_INTERVAL_TAG = "studyTimeInterval"
